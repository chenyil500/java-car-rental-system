/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author chyil
 */
public class classUser {

    //String id;
    String email;
    String name;
    String phoneNum;
    //String picID;

    public String[] login(String email, String pass) {
        String message = "Invalid user credential!";
        String user_email = null, user_role = null;
        ArrayList<String> arrUser = new ArrayList<>();
        try {
            FileReader fr = new FileReader("user.txt");
            Scanner input = new Scanner(fr);
            String[] lineArr;

            while (input.hasNext()) {
                String line = input.nextLine();
                lineArr = line.split(":");
                if (email.equals(lineArr[0])) {
                    if (pass.equals(lineArr[1])) {
                        message = "Logged in successfully!";
                        user_email = lineArr[0];
                        user_role = lineArr[2];

                    } else {
                        message = "Invalid password, please try again..";
                    }
                }
            }
        } catch (HeadlessException | FileNotFoundException e) {
            message = "Invalid credentials, please try again..";
        }

        arrUser.add(message); //message
        arrUser.add(user_email); //email
        arrUser.add(user_role); //role
        return arrUser.toArray(String[]::new);
    }

    //Check does the email exist
    public Boolean isSameEmail(String email) {
        Boolean isSame = true;
        classFileHandler obj = new classFileHandler();
        String data = obj.readFileWithId(email, "user.txt");
        if (data.isBlank()) {
            isSame = false;
        }

        return isSame;

    }

    //add to user txt
    public Boolean addUser(String email, String password, String role) {
        Boolean isSuccess = false;
        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("user.txt", true));
            output.write(email + ":" + password + ":" + role + ":" + "-1:0");
            output.newLine();
            output.flush();
            output.close();
            isSuccess = true;
        } catch (IOException e) {
            e.getStackTrace();
        }
        return isSuccess;
    }

    //Update security Question
    public String updateSecurityQuestion(String email, String questionID, String answer) {
        ArrayList<String> allRecord = viewAllRecord();
        String status = "Fail";

        //find the user that want to change
        classFileHandler obj = new classFileHandler();
        //0email:1password:2role:3questionID:4Answer
        String[] userInfo = obj.readFileWithId(email, "user.txt").split(":");
        userInfo[3] = questionID;
        userInfo[4] = answer;
        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(email)) {
                allRecord.set(i, String.join(":", userInfo));
            }
        }
        classFileHandler obj2 = new classFileHandler();
        Boolean isSuccess = obj2.editRecord("user.txt", allRecord, "0", false);
        if (isSuccess == true) {
            status = "Success";
        }

        return status;
    }

    //Update security Question
    public String updatePassword(String email, String old_password, String new_password) {
        ArrayList<String> allRecord = viewAllRecord();
        String status = "Fail";

        //find the user that want to change
        classFileHandler obj = new classFileHandler();
        //0email:1password:2role:3questionID:4Answer
        String[] userInfo = obj.readFileWithId(email, "user.txt").split(":");
        if (userInfo[1].equals(old_password)) {
            userInfo[1] = new_password;
            for (int i = 0; i < allRecord.size(); i++) {
                if (allRecord.get(i).split(":")[0].equals(email)) {
                    allRecord.set(i, String.join(":", userInfo));
                }
            }
            classFileHandler obj2 = new classFileHandler();
            Boolean isSuccess = obj2.editRecord("user.txt", allRecord, "0", false);
            if (isSuccess == true) {
                status = "Success";
            }
        } else {
            status = "Incorrect current password";
        }
        return status;

    }

    public ArrayList<String> viewAllRecord() {
        String filePath = "user.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);

        return arrInfo;
    }

    public String findPwd(String email, String questionNo, String answer) {
        String status = null;

        //read File
        File file = new File("user.txt");
        String data = new String();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    String[] datastring = line.split(":");
                    if (datastring[0].equals(email)) {
                        data = line;
                    }
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }

        String[] datastring = data.split(":");

        //find match or not
        if (!data.isBlank() && datastring[3].equals(questionNo) && datastring[4].equals(answer)) {
            String founded_password = datastring[1];
            status = "This is your password: " + founded_password;
        } else {
            status = "Incorrect Email/Question/Answer";
        }

        return status;

    }

    public String deleteUser(String email) {
        classFileHandler deleteAdmin = new classFileHandler();
        //get or read the full line 
        ArrayList<String> arrInfo = viewAllRecord();
        String line = deleteAdmin.readFileWithId(email, "user.txt");
        //delete
        deleteAdmin.deleteRecord("user.txt", line, arrInfo, "0", false);
        return null;

    }

}
