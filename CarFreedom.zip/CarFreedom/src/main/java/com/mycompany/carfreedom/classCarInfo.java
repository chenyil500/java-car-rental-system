/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author chyil
 */
public class classCarInfo {

    //member field
    private String carID;
    private String carName;
    private String seat;
    private String door;
    private String type;
    private String num_laggage;
    private String price;
    private String area;
    private String totalQuantity;
    private String carLeftNum;
    private String lagguage;
    private DefaultTableModel model;
    private DefaultTableModel modelFilter;

    //constructor
    public classCarInfo(String carID, String carName, String seat, String door, String type, String num_laggage, String price, String area, String totalQuantity, String carLeftNum) {
        this.carID = carID;
        this.carName = carName;
        this.seat = seat;
        this.door = door;
        this.type = type;
        this.num_laggage = num_laggage;
        this.price = price;
        this.area = area;
        this.totalQuantity = totalQuantity;
        this.carLeftNum = carLeftNum;
    }

    //for load car info
    public classCarInfo() {

    }

    public classCarInfo(ArrayList<String> data) {
        this.carName = data.get(0);
        this.seat = data.get(1);
        this.door = data.get(2);
        this.type = data.get(3);
        this.lagguage = data.get(4);
        this.price = data.get(5);
        this.area = data.get(6);
    }

    //method  
    //add or edit car info    
    public Boolean addCarInfo(String picName) {
        Boolean isSuccess = false;
        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("carInfo.txt", true));

            output.write(this.carID + ":" + this.carName + ":" + this.seat + ":" + this.door + ":" + this.type
                    + ":" + this.num_laggage + ":" + this.price + ":" + picName + ":" + this.area + ":" + this.totalQuantity + ":" + carLeftNum);
            output.newLine();
            output.flush();
            output.close();
            isSuccess = true;

        } catch (IOException e) {
            e.getStackTrace();
        }

        return isSuccess;
    }

    public Boolean isSameCarID() {
        Boolean isSameID = true;
        classFileHandler checkCarID = new classFileHandler();
        if (checkCarID.readFileWithId(this.carID, "carInfo.txt").isBlank()) {
            isSameID = false;
        }

        return isSameID;

    }

    public String uploadCarPic(String filename) {
        //seperate filename
        String[] arrOfPicName = filename.split("\\\\");
        String picName = arrOfPicName[arrOfPicName.length - 1];

        String newPath = "uploads/carImages";
        File directory = new File(newPath);

        //create directory if not exist
        if (!(directory.exists())) {
            directory.mkdirs();
        }

        File sourceFile = null;
        File destinationFile = null;

        sourceFile = new File(filename);
        destinationFile = new File(newPath + "\\\\" + picName);
        String extension = filename.substring(filename.lastIndexOf('.') + 1);
        //Check whether picture exist in folder
        while (destinationFile.exists()) {
            destinationFile = new File(destinationFile.toString().split("\\.")[0] + "copy." + extension);
        }
        try {
            Files.copy(sourceFile.toPath(), destinationFile.toPath());
        } catch (IOException ex) {
            Logger.getLogger(CarInfoDetail.class.getName()).log(Level.SEVERE, null, ex);
        }

        return splitPicName(destinationFile.toString());
    }

    public String splitPicName(String filePathName) {
        String[] arrSplitPicName = filePathName.split("\\\\");
        return arrSplitPicName[arrSplitPicName.length - 1];
    }

    //delete car info
    public void deleteCarInfo(String selectedID) {
        classFileHandler deleteCar = new classFileHandler();
        //get or read the full line 
        ArrayList<String> arrInfo = viewCarInfo();
        String line = deleteCar.readFileWithId(selectedID, "carInfo.txt");
        //delete
        deleteCar.deleteRecord("carInfo.txt", line, arrInfo, "", false);
    }

    //load car info
    public ArrayList<String> viewCarInfo() {
        String filePath = "carInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);
        return arrInfo;
    }
    

    public Boolean editCarInfo(String picName) {
        ArrayList<String> allRecord = viewCarInfo();
        String newRecord = this.carID + ":" + this.carName + ":" + this.seat + ":" + this.door + ":" + this.type
                + ":" + this.num_laggage + ":" + this.price + ":" + picName + ":" + this.area + ":" + this.totalQuantity + ":" + carLeftNum;
        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.carID)) {
                allRecord.set(i, newRecord);
            }
        }
        classFileHandler obj = new classFileHandler();
        Boolean isSuccess = obj.editRecord("carInfo.txt", allRecord, "0", false);
        return isSuccess;
    }
    
    //for customer use    
    public ArrayList<String> displayCarInfo() {

        String filepath = "carInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> carInfo = new ArrayList<String>();
        carInfo = obj.readFile(filepath);

        return carInfo;
    }

    public DefaultTableModel displayCarTable(Object carTable) {
        this.model = (DefaultTableModel) carTable;
        this.model.setRowCount(0);

        String filepath = "carInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> carTableData = new ArrayList<String>();
        carTableData = obj.readFile(filepath);
        for (int i = 1; i < carTableData.size(); i++) {
            String[] splitted = carTableData.get(i).split(":");
            this.model.addRow(new Object[]{splitted[0], splitted[1], splitted[2], splitted[3], splitted[4], splitted[5], splitted[6], splitted[8]});
        }

        return model;
    }

    public DefaultTableModel displayFilterTable(Object carTable) {
        this.modelFilter = (DefaultTableModel) carTable;
        this.modelFilter.setRowCount(0);

        Double priceHigh = Double.parseDouble(String.valueOf(this.price)) + 50;
        Double priceLow = Double.parseDouble(String.valueOf(this.price)) - 50;

        String filepath = "carInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> carFilterData = new ArrayList<String>();
        carFilterData = obj.readFile(filepath);

        for (int i = 1; i < carFilterData.size(); i++) {
            String[] splitted = carFilterData.get(i).split(":");
            if (splitted[2].equals(this.seat) || splitted[3].equals(this.door) || splitted[5].equals(this.lagguage) || splitted[1].toLowerCase().equals(this.carName.toLowerCase()) || splitted[4].equals(this.type) || (priceLow < Double.valueOf(splitted[6]) && priceHigh > Double.valueOf(splitted[6])) || splitted[8].equals(this.area)) {
                modelFilter.addRow(new Object[]{splitted[0], splitted[1], splitted[2], splitted[3], splitted[4], splitted[5], splitted[6], splitted[8]});

            }

        }
        return modelFilter;
    }

}
