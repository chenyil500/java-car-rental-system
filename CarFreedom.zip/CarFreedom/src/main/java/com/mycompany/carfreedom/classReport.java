/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author chyil
 */
public class classReport {
    //0BookingID:1CustomerID:2Price:3CarID:4Start Date:5End Date:6Rent Time:7Request Status:Car return Status:Return Time
    public ArrayList<String> viewAll(String filename) {
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filename);
        return arrInfo;
    }
    
    public void viewReport(String path) {

        File file = new File(path);
        try {
            Desktop desk = Desktop.getDesktop();
            desk.open(file);
        } catch (IOException ex) {
            Logger.getLogger(classReport.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
/*
    void generateReport(ArrayList<String> arrDetail) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    public abstract String generateReport(ArrayList<String> arrDetail) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
*/
}
