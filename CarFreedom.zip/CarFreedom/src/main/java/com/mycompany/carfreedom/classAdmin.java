/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class classAdmin extends classUser {

    //member field
    private String adminID;
    //private String email;
    //private String name;
    private String ic;
    private String city;
    //private String phoneNum;
    private String picID;

    //constructor
    public classAdmin() {

    }

    //constructor - overloading
    public classAdmin(String adminID, String email, String name, String ic, String city, String phoneNum, String picID) {
        this.adminID = adminID;
        this.email = email;
        this.name = name;
        this.ic = ic;
        this.city = city;
        this.phoneNum = phoneNum;
        this.picID = picID;
    }

    //constructor - overloading
    public classAdmin(String adminID) {
        this.adminID = adminID;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIc() {
        return ic;
    }

    public void setIc(String ic) {
        this.ic = ic;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getPicID() {
        return picID;
    }

    public void setPicID(String picID) {
        this.picID = picID;
    }

    public String setID() {
        classFileHandler obj = new classFileHandler();
        String id = obj.genID("ADM");
        return id;
    }

    public String createAdminAcc() {
        String status = "Fail";
        if (super.isSameEmail(email) == false) {
            try {
                String password = genPassword();
                //add to user txt
                if (super.addUser(email, password, "Admin") == true) {
                    //add in adminInfo txt
                    BufferedWriter output = new BufferedWriter(new FileWriter("adminInfo.txt", true));
                    this.adminID = setID();
                    output.write(this.adminID + ":" + this.email + ":" + this.name + ":" + this.ic + ":" + this.city + ":" + this.phoneNum + ":" + this.picID);
                    output.newLine();
                    output.flush();
                    output.close();
                    status = "Successfully create new account. \nAccount ID: " + this.adminID + "\nPassword: " + password;
                }
            } catch (IOException e) {
                e.getStackTrace();
            }
        } else {
            status = "Email already been regisrer!";
        }

        return status;
    }

    public String genPassword() {
        String pass = "admin";
        pass += this.ic.substring(this.ic.length() - 4);
        return pass;

    }

    public String deleteAdmin(String selectedID) {
        classFileHandler deleteAdmin = new classFileHandler();
        //get or read the full line 
        ArrayList<String> arrInfo = viewAdminInfo();
        String line = deleteAdmin.readFileWithId(selectedID, "adminInfo.txt");
        //delete
        deleteAdmin.deleteRecord("adminInfo.txt", line, arrInfo, "0", false);
        return null;

    }

    public ArrayList<String> viewAdminInfo() {
        String filePath = "adminInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);

        return arrInfo;
    }

    public String updateAdmin() {
        ArrayList<String> allRecord = viewAdminInfo();
        String status = "Fail";
        String newRecord = this.adminID + ":" + this.email + ":" + this.name + ":" + this.ic + ":" + this.city + ":" + this.phoneNum + ":" + this.picID;
        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.adminID)) {
                allRecord.set(i, newRecord);
            }
        }
        classFileHandler obj = new classFileHandler();
        Boolean isSuccess = obj.editRecord("adminInfo.txt", allRecord, "0", false);
        if (isSuccess == true) {
            status = "Success";
        }

        return status;

    }

    //view profile
    public static void viewProfile(classAdmin o1, String record) {

        //0adminID:1Email:2Name:3IC:4City:5ContactNum:6PicID
        String[] splitted = record.split(":");

        o1.email = splitted[1];
        o1.name = splitted[2];
        o1.ic = splitted[3];
        o1.city = splitted[4];
        o1.phoneNum = splitted[5];
        o1.picID = splitted[6];

    }

    //change picture
    public String changePic(String pic) {
        this.picID = pic;

        ArrayList<String> allRecord = viewAdminInfo();
        String status = null;

        classFileHandler obj = new classFileHandler();
        String record = obj.readFileWithId(this.adminID, "adminInfo.txt");
        //0adminID:1Email:2Name:3IC:4City:5ContactNum:6PicID
        String[] record_split = record.split(":");
        record_split[6] = this.picID;
        record = String.join(":", record_split);

        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.adminID)) {
                allRecord.set(i, record);
            }
        }

        Boolean isSuccess = obj.editRecord("adminInfo.txt", allRecord, "0", false);

        if (isSuccess == true) {
            status = "Update Successfully.";
        } else {
            status = "Unable to update.";
        }
        return status;
    }

    public String getAdminRecord() {
        classFileHandler obj1 = new classFileHandler();
        String record = obj1.readFileWithId(this.adminID, "adminInfo.txt");
        return record;
    }

     public String displayUsername(String email){
        classFileHandler obj1 = new classFileHandler();
        String record = obj1.readFileWithId(email, "adminInfo.txt").split(":")[2];
     
        return record;
     
     
     }
     
     public String findAdminID(String email){
        classFileHandler obj1 = new classFileHandler();
        String record = obj1.readFileWithId(email, "adminInfo.txt");
         
        return record.split(":")[0];
         
         
     }
}
