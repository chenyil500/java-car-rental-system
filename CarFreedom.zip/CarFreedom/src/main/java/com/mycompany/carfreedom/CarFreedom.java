/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.carfreedom;

/**
 *
 * @author ziyou
 */
public class CarFreedom {

    public static void main(String[] args) {
        WelcomePage welcome = new WelcomePage();
        welcome.setVisible(true); //to show the Main page
    }
}
