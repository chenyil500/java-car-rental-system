/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class classFileHandler {

    public ArrayList<String> readFile(String filePath) {

        File file = new File(filePath);
        ArrayList<String> arrInfo = new ArrayList<String>();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    arrInfo.add(line);
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error in closing the BufferedReader");
            }
        }

        return arrInfo;

    }

    public String readFileWithId(String id, String filename) {
        File file = new File(filename);
        String data = new String();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    String[] datastring = line.split(":");
                    if (datastring[0].equals(id)) {
                        data = line;
                    } else if (datastring[1].equals(id) && id.contains("@")) {
                        data = line;
                    }
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }
        return data;
    }
    
    public ArrayList<String> readFileWithEmail(String email, String filename) {
        File file = new File(filename);
        ArrayList<String> data = new ArrayList<String>();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    String[] datastring = line.split(":");
                    if (datastring[3].equals(email)) {
                        data.add(line);
                    }
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }
        return data;
    }
    
    public ArrayList<String> readFileWithVoucher(String id, String filename) {
        
        File file = new File(filename);
        ArrayList<String> dataVoucher = new ArrayList<String>();
        if (file.exists()) {
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null) {
                    if (line.startsWith(id)) {

                        dataVoucher.add(line);
                        break;
                    }
                    line = br.readLine();
                }
                br.close();
            } catch (IOException ex) {
                System.out.println("Error");
            }
        }

        return dataVoucher;
    }

    public void deleteRecord(String filename, String deletedLine, ArrayList<String> allRecord, String header, Boolean isHeader) {

        try {
            FileWriter fw = new FileWriter(filename);
            BufferedWriter bw = new BufferedWriter(fw);
            if (isHeader == true) {
                bw.write(header);
                bw.newLine();
            }
            for (int i = 0; i < allRecord.size(); i++) {
                while (!deletedLine.equals(allRecord.get(i))) {
                    bw.write(allRecord.get(i));
                    bw.newLine();
                    break;
                }
            }
            bw.close();
            fw.close();

        } catch (IOException ex) {
            System.out.println("Error");
        }

    }

    public Boolean editRecord(String filename, ArrayList<String> allRecord, String header, Boolean isHeader) {
        Boolean isSuccess = false;
        try {
            FileWriter fw = new FileWriter(filename);
            BufferedWriter bw = new BufferedWriter(fw);
            if (isHeader == true) {
                bw.write(header);
                bw.newLine();
            }
            for (int i = 0; i < allRecord.size(); i++) {
                bw.write(allRecord.get(i));
                bw.newLine();
            }

            bw.close();
            fw.close();

            isSuccess = true;

        } catch (IOException ex) {
            System.out.println("Error");
        }
        return isSuccess;

    }

    public String genID(String type) {
        String oldID = null;
        String newID = null;
        String newLine = null;
        String newIDName = null;

        ArrayList<String> data = new ArrayList<String>();
        data = readFile("id.txt");
        //update id
        if (type.equals("ADM")) {
            oldID = data.get(1).strip().split(":")[0];
        } else if (type.equals("BK")) {
            oldID = data.get(1).strip().split(":")[1];
        } else if (type.equals("CUS")) {
            oldID = data.get(1).strip().split(":")[2];
        }
        int nextID = Integer.parseInt(oldID) + 1;
        switch (String.valueOf(nextID).length()) {
            case 1 ->
                newID = "00" + String.valueOf(nextID);
            case 2 ->
                newID = "0" + String.valueOf(nextID);
            case 3 ->
                newID = String.valueOf(nextID);
            default -> {
            }
        }
        newIDName = type + newID;
        if (type.equals("ADM")) {
            newLine = newID + ":" + data.get(1).strip().split(":")[1] + ":" + data.get(1).strip().split(":")[2];
        } else if (type.equals("BK")) {
            newLine = data.get(1).strip().split(":")[0] + ":" + newID  + ":" + data.get(1).strip().split(":")[2];
        } else if (type.equals("CUS")) {
            newLine = data.get(1).strip().split(":")[0]  + ":" + data.get(1).strip().split(":")[1] + ":" + newID;
        }
        data.set(1, newLine);
        editRecord("id.txt", data, "0", false);

        return newIDName;
    }

}
