/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ziyou
 */
public class classBookingInfo {

    //member field
    private Long duration;
    private Double oriAmount;
    private String voucherID;
    private String deductAmount;
    private String voucherType;
    private String deductPercentage;
    private String newPrice;
    private String start;
    private String end;
    private String email;
    private String carID;
    private String carName;
    private String area;
    private String dateFrom;
    private String dateTo;
    private String dayBook;
    private String priceTotal;
    private String cusID;
    private String rentTime;
    private String cmbChoise;

    private DefaultTableModel modelHistory;
    private DefaultTableModel modelStatus;
    private DefaultTableModel modelFilterStatus;
    private DefaultTableModel modelFilterHistory;

    String[] wanID = null;

    ArrayList<String> data = new ArrayList<>();

    public classBookingInfo() {

    }

    public classBookingInfo(String cus_email) {
        this.email = cus_email;

    }

    public classBookingInfo(String cus_email, String choise) {
        this.email = cus_email;
        this.cmbChoise = choise;

    }

    public classBookingInfo(String email, String carID, String carName, String area, String dateFrom, String dateTo, String day, String totalPrice) {
        this.carID = carID;
        this.email = email;
        this.carName = carName;
        this.area = area;
        this.dateFrom = dateFrom;
        this.dateTo = dateTo;
        this.dayBook = day;
        this.priceTotal = totalPrice;

    }

    public String getRentTime() {
        return rentTime;
    }

    public void setRentTime(String rentTime) {
        this.rentTime = rentTime;
    }

    public String getCusID() {
        return cusID;
    }

    public void setCusID(String cusID) {
        this.cusID = cusID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCarID() {
        return carID;
    }

    public void setCarID(String carID) {
        this.carID = carID;
    }

    public String getCarName() {
        return carName;
    }

    public void setCarName(String carName) {
        this.carName = carName;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getDateFrom() {
        return dateFrom;
    }

    public void setDateFrom(String dateFrom) {
        this.dateFrom = dateFrom;
    }

    public String getDateTo() {
        return dateTo;
    }

    public void setDateTo(String dateTo) {
        this.dateTo = dateTo;
    }

    public String getDayBook() {
        return dayBook;
    }

    public void setDayBook(String dayBook) {
        this.dayBook = dayBook;
    }

    public String getPriceTotal() {
        return priceTotal;
    }

    public void setPriceTotal(String priceTotal) {
        this.priceTotal = priceTotal;
    }

    //method
    public String calTotlPayment(Long day, String price) {
        this.duration = day;

        Double result = this.duration * Double.parseDouble(price);

        return Double.toString(result);
    }

    public String checkVoucher(String code, String totalPrice) {

        DecimalFormat df = new DecimalFormat("0.00");

        ArrayList<String> dataVoucher = new ArrayList<String>();
        String filepath = "voucher.txt";
        classFileHandler cv = new classFileHandler();

        dataVoucher = cv.readFileWithVoucher(code, filepath);
        for (int i = 0; i < dataVoucher.size(); i++) {
            String[] splitted = dataVoucher.get(i).split(":");
            if (splitted[0] != null) {
                this.voucherID = splitted[0];
                this.start = splitted[2];
                this.end = splitted[3];
                this.voucherType = splitted[5];
                this.deductAmount = splitted[6];
                this.deductPercentage = splitted[6];

                if (this.voucherType.equals("By Percentages")) {
                    Double newPrice = Double.parseDouble(totalPrice) - (Double.parseDouble(totalPrice) * Double.parseDouble(this.deductPercentage) / 100);
                    String newnew = df.format(newPrice);

                    this.newPrice = newnew;

                } else {
                    Double newPrice = Double.parseDouble(totalPrice) - Double.parseDouble(this.deductAmount);
                    String newnew = df.format(newPrice);

                    this.newPrice = newnew;
                }
            }
        }
        return this.newPrice;

    }

    public String setID() {
        classFileHandler obj = new classFileHandler();
        String id = obj.genID("BK");
        return id;
    }

    public ArrayList<String> updateBooking() {
        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("booking.txt", true));
            classFileHandler CID = new classFileHandler();
            ArrayList<String> customerID = CID.readFileWithEmail(this.email, "cusInfo.txt");

            for (int i = 0; i < customerID.size(); i++) {
                String[] splitted = customerID.get(i).split(":");
                this.cusID = splitted[0];
            }
            String BookingID = setID();

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            Date today = Calendar.getInstance().getTime();
            this.rentTime = df.format(today);

            setValue();

            output.write(BookingID + ":" + this.cusID + ":" + this.priceTotal + ":" + this.carID + ":" + this.dateFrom + ":" + this.dateTo + ":" + rentTime + ":" + "pending" + ":" + "No returned yet!" + ":" + "-1");
            output.newLine();
            output.flush();
            output.close();

        } catch (IOException ex) {
            Logger.getLogger(classBookingInfo.class.getName()).log(Level.SEVERE, null, ex);
        }
        return this.data;
    }

    public void setValue() {
        data.clear();

        classBookingInfo obj = new classBookingInfo();
        data.add(this.email); //0
        data.add(this.cusID); //1
        data.add(this.carName); //2
        data.add(this.area); //3
        data.add(this.dateFrom); //4
        data.add(this.dateTo); //5
        data.add(this.priceTotal); //6
        data.add(this.rentTime); //7

    }

    public void findCusID() {
        classFileHandler fh = new classFileHandler();
        ArrayList<String> ID = fh.readFileWithEmail(this.email, "cusInfo.txt");

        for (int i = 0; i < ID.size(); i++) {
            String[] splitted = ID.get(i).split(":");
            this.cusID = splitted[0];
        }
    }

    public void updateFeedBack(ArrayList<String> feedback, String carID) {
        findCusID();
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date today = Calendar.getInstance().getTime();
        this.rentTime = df.format(today);

        String carCon = feedback.get(0);
        String bookCon = feedback.get(1);
        String serCon = feedback.get(2);
        String priceCon = feedback.get(3);

        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("feedback.txt", true));
            output.write(carID + ":" + this.cusID + ":" + this.rentTime + ":" + carCon + ":" + bookCon + ":" + serCon + ":" + priceCon);
            output.newLine();
            output.flush();
            output.close();
            
        } catch (IOException ex) {
            Logger.getLogger(classBookingInfo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public DefaultTableModel displayHistory(Object historyTable) {
        findCusID();

        this.modelHistory = (DefaultTableModel) historyTable;
        this.modelHistory.setRowCount(0);

        String filepath = "booking.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> hisData = new ArrayList<String>();
        hisData = obj.readFile(filepath);

        for (int i = 1; i < hisData.size(); i++) {
            String[] splitted = hisData.get(i).split(":");
            if (!splitted[7].equals("pending") && splitted[1].equals(this.cusID)) {
                modelHistory.addRow(new Object[]{splitted[0], splitted[3], splitted[2], splitted[6], splitted[7]});
            }
        }
        return modelHistory;
    }

    public DefaultTableModel filterHistory(Object historyTable) {
        findCusID();

        this.modelFilterHistory = (DefaultTableModel) historyTable;
        this.modelFilterHistory.setRowCount(0);

        String filepath = "booking.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> statusData = new ArrayList<String>();
        statusData = obj.readFile(filepath);

        for (int i = 1; i < statusData.size(); i++) {
            String[] splitted = statusData.get(i).split(":");
            if (!splitted[7].equals("pending") && splitted[1].equals(this.cusID) && splitted[6].equals(this.cmbChoise)) {
                modelFilterHistory.addRow(new Object[]{splitted[0], splitted[3], splitted[2], splitted[6], splitted[7]});
            }
        }
        return modelFilterHistory;
    }

    public DefaultTableModel displayStatus(Object statusTable) {
        findCusID();

        this.modelStatus = (DefaultTableModel) statusTable;
        this.modelStatus.setRowCount(0);

        String filepath = "booking.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> statusData = new ArrayList<String>();
        statusData = obj.readFile(filepath);

        for (int i = 1; i < statusData.size(); i++) {
            String[] splitted = statusData.get(i).split(":");
            if (splitted[1].equals(this.cusID)) {
                modelStatus.addRow(new Object[]{splitted[0], splitted[6], splitted[3], splitted[7]});
            }
        }
        return modelStatus;
    }

    public DefaultTableModel filterStatus(Object statusTable) {
        findCusID();

        this.modelFilterStatus = (DefaultTableModel) statusTable;
        this.modelFilterStatus.setRowCount(0);

        String filepath = "booking.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> statusData = new ArrayList<String>();
        statusData = obj.readFile(filepath);

        for (int i = 1; i < statusData.size(); i++) {
            String[] splitted = statusData.get(i).split(":");
            if (splitted[1].equals(this.cusID) && splitted[7].equals(this.cmbChoise)) {
                modelFilterStatus.addRow(new Object[]{splitted[0], splitted[6], splitted[3], splitted[7]});
            }
        }
        return modelFilterStatus;
    }
}

//check time
//check voucher used
//    //get current time
//    public String getCurrentDateTime() {
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
//        Date date = new Date();
//        String currentTime = formatter.format(date);
//
//        return currentTime;
//    }
