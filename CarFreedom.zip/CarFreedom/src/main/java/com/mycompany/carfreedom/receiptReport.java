/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class receiptReport extends classReport implements report {

    @Override
    public String generateReport(ArrayList<String> allRecord) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String generatePDFReport(ArrayList<String> allRecord, String total) {
        String datetime = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        String datetime2 = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDateTime.now());
        String file = "Receipt/" + datetime + " receipt.pdf";
        //created PDF document instance   
        Document doc = new Document();
        try {

            //generate a PDF at the specified location  
            PdfWriter.getInstance(doc, new FileOutputStream(file));
            //opens the PDF 
            doc.open();

            float fntSize, lineSpacing;
            fntSize = 50f;
            lineSpacing = 10f;
            Paragraph p = new Paragraph(new Phrase(lineSpacing, "\n\n\n\n\nReceipt\n\n\n",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, fntSize)));
            doc.add(p);
            doc.add(new Paragraph("Generate Date: " + datetime2 + "\n\n"));
            doc.add(new Paragraph("*************************************"));
            Paragraph p2 = new Paragraph(total);
            doc.add(p2);

            //close the PDF file  
            doc.close();
        } catch (DocumentException | FileNotFoundException e) {
            System.out.println("Sad");
        }
        return file;
    }

    @Override
    public String showTotal(int month, int year) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public ArrayList<String> filterData(ArrayList<String> allRecord, int month, int year) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
