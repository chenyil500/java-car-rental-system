/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ziyou
 */
public class ClassCustomer extends classUser {

    //member field
    private String CustomerID;
    private String username;
    private String IC;
    String email;
    private String LEDDate;
    private String number;
    private String bornDate;
    private String role;
    private String pwd;

    //constructor
    public ClassCustomer() {

    }

    public ClassCustomer(String CustomerID, String username, String IC, String email, String LEDDate, String number, String bornDate, String pwd) {
        this.CustomerID = CustomerID;
        this.username = username;
        this.IC = IC;
        this.email = email;
        this.LEDDate = LEDDate;
        this.number = number;
        this.bornDate = bornDate;
        this.pwd = pwd;
    }

    public ClassCustomer(String CustomerID, String username, String IC, String email, String LEDDate, String number, String bornDate) {
        this.CustomerID = CustomerID;
        this.username = username;
        this.IC = IC;
        this.email = email;
        this.LEDDate = LEDDate;
        this.number = number;
        this.bornDate = bornDate;
    }

    public ClassCustomer(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(String CustomerID) {
        this.CustomerID = CustomerID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAge() {
        return IC;
    }

    public void setAge(String age) {
        this.IC = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLxDate() {
        return LEDDate;
    }

    public void setLxDate(String lxDate) {
        this.LEDDate = lxDate;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getBornDate() {
        return bornDate;
    }

    public void setBornDate(String bornDate) {
        this.bornDate = bornDate;
    }

    public String setID() {
        classFileHandler obj = new classFileHandler();
        String id = obj.genID("CUS");

        return id;
    }

    public ArrayList<String> viewCusInfo() {
        String filePath = "cusInfo.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);

        return arrInfo;
    }

    public Boolean checkRole(String email) {
        Boolean role = false;
        ArrayList<String> allRecord = viewCusInfo();
        classFileHandler obj = new classFileHandler();
        ArrayList<String> record = obj.readFile("user.txt");

        record.set(2, this.role);
        if (record.set(2, this.role) == "customer") {
            role = true;
        } else {
            role = false;
        }

        return role;
    }

    public String createCustomer() {
        String status = "fail";
        if (super.isSameEmail(email) == false) {
            if (super.addUser(email, pwd, "Customer") == true) {
                try {
                    BufferedWriter output = new BufferedWriter(new FileWriter("cusInfo.txt", true));
                    this.CustomerID = setID();
                    output.write(this.CustomerID + ":" + this.username + ":" + this.IC + ":" + this.email + ":" + this.LEDDate + ":" + this.number + ":" + this.bornDate);
                    output.newLine();
                    output.flush();
                    output.close();
                    status = "Successfully create new account. \nAccount ID: " + this.CustomerID;
                } catch (IOException ex) {
                    Logger.getLogger(ClassCustomer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } else {
            status = "Email already registered";
        }
        return status;
    }

    public String updateCus() {
        ArrayList<String> allRecord = viewCusInfo();
        String status = "Fail";
        String newRecord = this.CustomerID + ":" + this.username + ":" + this.IC + ":" + this.email + ":" + this.LEDDate + ":" + this.number + ":" + this.bornDate;
        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.CustomerID)) {
                allRecord.set(i, newRecord);
            }
        }
        classFileHandler obj = new classFileHandler();
        Boolean isSuccess = obj.editRecord("cusInfo.txt", allRecord, "0", false);
        if (isSuccess == true) {
            status = "Success";
        }
        return status;

    }

}
