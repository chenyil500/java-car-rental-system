/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class salesReport extends classReport implements report {

    /**
     *
     * @param allRecord
     * @return
     */
    @Override
    public String generateReport(ArrayList<String> allRecord) {

        String datetime = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());

        String file = "SalesReport/" + datetime + " sales.csv";
        try {
            FileWriter Writer = new FileWriter(file);
            BufferedWriter buffer = new BufferedWriter(Writer);
            buffer.append("BookingID, CustomerID, CarID, Income");
            buffer.newLine();
            for (int i = 0; i < allRecord.size(); i++) {
                buffer.append(allRecord.get(i).split(":")[0] + ",");
                buffer.append(allRecord.get(i).split(":")[1] + ",");
                buffer.append(allRecord.get(i).split(":")[3] + ",");
                buffer.append(allRecord.get(i).split(":")[2] + ",");
                /*
                for (int j = 0; j < allRecord.size(); j++) {
                    buffer.append(allRecord.get(i).split(":")[j] + ",");
                }
                 */
                buffer.newLine();
            }

            buffer.flush();
            buffer.close();
        } catch (Exception e) {
            e.getStackTrace();
        }

        return file;
    }

    @Override
    public String generatePDFReport(ArrayList<String> allRecord, String total) {

        String datetime = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        String datetime2 = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDateTime.now());
        String file = "SalesReport/" + datetime + " sales.pdf";
        //created PDF document instance   
        Document doc = new Document();
        try {

            //generate a PDF at the specified location  
            PdfWriter.getInstance(doc, new FileOutputStream(file));
            //opens the PDF 
            doc.open();

            float fntSize, lineSpacing;
            fntSize = 50f;
            lineSpacing = 10f;
            Paragraph p = new Paragraph(new Phrase(lineSpacing, "\n\n\n\n\nSales Report\n\n\n",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, fntSize)));
            doc.add(p);
            doc.add(new Paragraph("Generate Date: " + datetime2 +"\n\n"));

            PdfPTable tb = new PdfPTable(4);

            tb.addCell("Booking ID");
            tb.addCell("Customer ID");
            tb.addCell("Car ID");
            tb.addCell("Income");

            for (int i = 0; i < allRecord.size(); i++) {
                tb.addCell(allRecord.get(i).split(":")[0]);
                tb.addCell(allRecord.get(i).split(":")[1]);
                tb.addCell(allRecord.get(i).split(":")[3]);
                tb.addCell(allRecord.get(i).split(":")[2]);
            }

            doc.add(tb);
            
            Paragraph p2 = new Paragraph(new Phrase(lineSpacing, "\n\n" + total,
                    FontFactory.getFont(FontFactory.TIMES_BOLD, 20f)));
            doc.add(p2);
            //close the PDF file  
            doc.close();
        } catch (DocumentException | FileNotFoundException e) {
            System.out.println("Sad");
        }

        return file;
    }

    @Override
    public String showTotal(int month, int year) {
        //BookingID:CustomerID:Price:CarID:Start Date:End Date:Rent Time:Request Status:Car return Status:Return Time
        ArrayList<String> allRecord = super.viewAll("booking.txt");
        ArrayList<String> filterData = filterData(allRecord, month, year);
        return calTotal(filterData);
    }

    @Override
    public ArrayList<String> filterData(ArrayList<String> allRecord, int month, int year) {
        ArrayList<String> newData = new ArrayList<>();
        for (int i = 1; i < allRecord.size(); i++) {
            String dateRent = allRecord.get(i).split(":")[6];
            int yearData = Integer.parseInt(dateRent.split("-")[0]);
            int monthData = Integer.parseInt(dateRent.split("-")[1]);
            if (yearData == year && monthData == month && "accept".equals(allRecord.get(i).split(":")[7])) {
                newData.add(allRecord.get(i));
            } else if (month == -1 && year == -1 && "accept".equals(allRecord.get(i).split(":")[7])) {
                newData.add(allRecord.get(i));
            }
        }

        return newData;
    }

    public String calTotal(ArrayList<String> filterData) {
        double sum = 0;
        for (int i = 0; i < filterData.size(); i++) {
            sum += Double.parseDouble(filterData.get(i).split(":")[2]);
        }

        return Double.toString(sum);

    }

    public ArrayList<String> showAllFilterData(int month, int year) {
        //BookingID:CustomerID:Price:CarID:Start Date:End Date:Rent Time:Request Status:Car return Status:Return Time
        ArrayList<String> allRecord = super.viewAll("booking.txt");
        ArrayList<String> filterData = filterData(allRecord, month, year);
        return filterData;
    }

}
