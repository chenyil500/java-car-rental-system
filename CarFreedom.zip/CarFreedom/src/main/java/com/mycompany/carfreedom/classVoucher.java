/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class classVoucher {

    //member field
    private String name;
    private String code;
    private String start;
    private String end;
    private String targetedCustomer;
    private String type;
    private String amount;
    private String maxPrice;
    private String limit;

    //constructor
    public classVoucher(String name, String code, String start, String end, String targetCustomer, String type, String amount, String maxPrice, String limit) {
        this.name = name;
        this.code = code;
        this.start = start;
        this.end = end;
        this.targetedCustomer = targetCustomer;
        this.type = type;
        this.amount = amount;
        this.maxPrice = maxPrice;
        this.limit = limit;
    }
    
    public classVoucher(){}

    public Boolean isSameCode() {
        Boolean isSameID = true;
        classFileHandler checkCarID = new classFileHandler();
        if (checkCarID.readFileWithId(this.code, "voucher.txt").isBlank()) {
            isSameID = false;
        }

        return isSameID;
    }

    public String addNewVoucher() {
        String result = "Fail to add new voucher!!";
        try {
            BufferedWriter output = new BufferedWriter(new FileWriter("voucher.txt", true));

            output.write(this.code + ":" + this.name + ":" + this.start + ":" + this.end + ":" + this.targetedCustomer
                    + ":" + this.type + ":" + this.amount + ":" + this.maxPrice + ":" + this.limit);
            output.newLine();
            output.flush();
            output.close();
            result = "Succesfully add new voucher!";

        } catch (IOException e) {
            e.getStackTrace();
        }

        return result;
    }
    
    //load voucher info
    public ArrayList<String> viewVoucherInfo() {
        String filePath = "voucher.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);

        return arrInfo;
    }
    
    //delete voucher
    public void deleteVoucher(String selectedCode) {
        classFileHandler deleteCar = new classFileHandler();
        //get or read the full line 
        ArrayList<String> arrInfo = viewVoucherInfo();
        String line = deleteCar.readFileWithId(selectedCode, "voucher.txt");
        //delete
        deleteCar.deleteRecord( "voucher.txt", line, arrInfo, "0", false);
    }
}
