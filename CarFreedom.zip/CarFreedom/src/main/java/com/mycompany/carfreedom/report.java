/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.carfreedom;

import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public interface report {
    public String generateReport(ArrayList<String> allRecord);
    public String generatePDFReport(ArrayList<String> allRecord, String total);
    public String showTotal(int month, int year);
    public ArrayList<String> filterData(ArrayList<String> allRecord, int month, int year);
}
