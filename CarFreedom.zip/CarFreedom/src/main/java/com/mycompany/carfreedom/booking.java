/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author chyil
 */
public class booking {

    //member field
    private String bookingID = "BK001";
    private String customerID;
    private String price;
    private String carID;
    private String start_date;
    private String end_date;
    private String request_status;
    private String car_return_status;

    //constructor
    public booking(String bookingID) {
        this.bookingID = bookingID;

    }

    public booking() {

    }

    public ArrayList<String> viewBookingInfo() {
        String filePath = "booking.txt";
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>();
        arrInfo = obj.readFile(filePath);

        return arrInfo;

    }
    
    public ArrayList<String> getPendingInfo() {
        ArrayList<String> arrInfo = viewBookingInfo();
        ArrayList<String> newInfo = new ArrayList<String>();
        for (int i = 1; i < arrInfo.size(); i++) {
            String[] splitted = arrInfo.get(i).split(":");
            if (splitted[7].equals("pending")){
                newInfo.add(arrInfo.get(i));
            }                      
        }

        return newInfo;

    }

    //BookingID, CarID,  Duration, Price  , CarName, Cusid, name, license, age, email, contactNum 
    public ArrayList<String> displayResponsePage() {
        ArrayList<String> arrDisplayInfo = new ArrayList<String>();

        //booking - BookingID, CarID, Duration, Price
        classFileHandler obj = new classFileHandler();
        ArrayList<String> arrInfo = new ArrayList<String>(Arrays.asList(obj.readFileWithId(this.bookingID, "booking.txt").split(":")));
        arrDisplayInfo.add(arrInfo.get(0)); //BookingID
        arrDisplayInfo.add(arrInfo.get(3)); //CarID
        arrDisplayInfo.add(calDuration(arrInfo.get(4), arrInfo.get(5))); //Duration
        arrDisplayInfo.add(arrInfo.get(2)); //Price
        String cusID = arrInfo.get(1);

        //car
        arrInfo = new ArrayList<String>(Arrays.asList(obj.readFileWithId(arrDisplayInfo.get(1), "carInfo.txt").split(":")));
        arrDisplayInfo.add(arrInfo.get(1)); //CarName
        
        //Customer Detail - id, name, license, age, email, contactNum 
        arrInfo = new ArrayList<String>(Arrays.asList(obj.readFileWithId(cusID, "cusInfo.txt").split(":")));
        arrDisplayInfo.add(cusID); //cusID
        arrDisplayInfo.add(arrInfo.get(1)); //name
        arrDisplayInfo.add(arrInfo.get(4)); //license
        arrDisplayInfo.add(arrInfo.get(2)); //Age
        arrDisplayInfo.add(arrInfo.get(3)); //Email
        arrDisplayInfo.add(arrInfo.get(5)); //license
        return arrDisplayInfo;
    }

    public String updateRequestStatus(String response) {
        ArrayList<String> allRecord = viewBookingInfo();
        String status = "Fail";

        classFileHandler obj = new classFileHandler();
        String[] info = obj.readFileWithId(this.bookingID, "booking.txt").split(":");
        info[7] = response;

        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.bookingID)) {
                allRecord.set(i, String.join(":", info));
            }
        }

        Boolean isSuccess = obj.editRecord("booking.txt", allRecord, "0", false);
        if (isSuccess == true) {
            status = "Success";
        }

        return status;

    }

    public String updateReturnStatus() {
        ArrayList<String> allRecord = viewBookingInfo();
        String status = "Fail";

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate now = LocalDate.now();

        classFileHandler obj = new classFileHandler();
        String[] info = obj.readFileWithId(this.bookingID, "booking.txt").split(":");
        info[8] = "Returned";
        info[9] = formatter.format(now);

        for (int i = 0; i < allRecord.size(); i++) {
            if (allRecord.get(i).split(":")[0].equals(this.bookingID)) {
                allRecord.set(i, String.join(":", info));
            }
        }

        Boolean isSuccess = obj.editRecord("booking.txt", allRecord, "0", false);
        if (isSuccess == true) {
            status = "Success";
        }

        return status;

    }

    public String calDuration(String startDate, String endDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        //convert String to LocalDate
        LocalDate localStart = LocalDate.parse(startDate, formatter);
        LocalDate localEnd = LocalDate.parse(endDate, formatter);

        long duration = ChronoUnit.DAYS.between(localStart, localEnd);

        return Long.toString(duration);

    }

    public String setPendingNum() {
        //BookingID:CustomerID:Price:CarID:Start Date:End Date:Rent Time:Request Status:Car return Status:Return Time
        int sum = 0;
        ArrayList<String> arrInfo = viewBookingInfo();
        for (int i = 1; i < arrInfo.size(); i++) {
            String[] splitted = arrInfo.get(i).split(":");
            if (splitted[7].equals("pending")){
                sum += 1;
            }                      
        }
        return Integer.toString(sum);
    }
}
