/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.carfreedom;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 *
 * @author chyil
 */
public class feedbackReport extends classReport implements report {

    /**
     *
     * @param allRecord
     * @return
     */
    @Override
    public String generateReport(ArrayList<String> allRecord) {

        String datetime = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        String file = "FeedbackReport/" + datetime + " feedback.csv";
        try {
            FileWriter Writer = new FileWriter(file);
            BufferedWriter buffer = new BufferedWriter(Writer);
            buffer.append("CarID, CustomerID, Car Rating, Booking Rating, Service Rating, Price Rating, Overall Rating");
            buffer.newLine();
            for (int i = 0; i < allRecord.size(); i++) {
                buffer.append(allRecord.get(i).split(":")[0] + ",");
                buffer.append(allRecord.get(i).split(":")[1] + ",");
                buffer.append(allRecord.get(i).split(":")[3] + ",");
                buffer.append(allRecord.get(i).split(":")[4] + ",");
                buffer.append(allRecord.get(i).split(":")[5] + ",");
                buffer.append(allRecord.get(i).split(":")[6] + ",");
                buffer.append(allRecord.get(i).split(":")[7] + ",");
                buffer.newLine();
            }

            buffer.flush();
            buffer.close();
        } catch (IOException e) {
            e.getStackTrace();
        }

        return file;

    }

    @Override
    public String generatePDFReport(ArrayList<String> allRecord, String total) {

        String datetime = DateTimeFormatter.ofPattern("ddMMyyyyHHmmss").format(LocalDateTime.now());
        String datetime2 = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(LocalDateTime.now());
        String file = "FeedbackReport/" + datetime + " feedback.pdf";
        //created PDF document instance   
        Document doc = new Document();
        try {

            //generate a PDF at the specified location  
            PdfWriter.getInstance(doc, new FileOutputStream(file));
            //opens the PDF 
            doc.open();

            float fntSize, lineSpacing;
            fntSize = 50f;
            lineSpacing = 10f;
            Paragraph p = new Paragraph(new Phrase(lineSpacing, "\n\n\n\n\nFeedback Report\n\n\n",
                    FontFactory.getFont(FontFactory.TIMES_BOLD, fntSize)));
            doc.add(p);
            doc.add(new Paragraph("Generate Date: " + datetime2 + "\n\n"));

            PdfPTable tb = new PdfPTable(7);
            tb.addCell("CarID");
            tb.addCell("CustomerID");
            tb.addCell("Car Rating");
            tb.addCell("Booking Rating");
            tb.addCell("Service Rating");
            tb.addCell("Price Rating");
            tb.addCell("Overall Rating");

            for (int i = 0; i < allRecord.size(); i++) {
                tb.addCell(allRecord.get(i).split(":")[0]);
                tb.addCell(allRecord.get(i).split(":")[1]);
                tb.addCell(allRecord.get(i).split(":")[3]);
                tb.addCell(allRecord.get(i).split(":")[4]);
                tb.addCell(allRecord.get(i).split(":")[5]);
                tb.addCell(allRecord.get(i).split(":")[6]);
                tb.addCell(allRecord.get(i).split(":")[7]);
            }

            doc.add(tb);

            Paragraph p2 = new Paragraph(new Phrase(lineSpacing, "\n\n" + total,
                    FontFactory.getFont(FontFactory.TIMES_BOLD, 20f)));
            doc.add(p2);
            //close the PDF file  
            doc.close();
        } catch (DocumentException | FileNotFoundException e) {
            System.out.println("Sad");
        }

        return file;
    }

    @Override
    public String showTotal(int month, int year) {
        double overalTotal = 0;
        //BookingID:CustomerID:Price:CarID:Start Date:End Date:Rent Time:Request Status:Car return Status:Return Time
        ArrayList<String> allRecord = super.viewAll("feedback.txt");
        ArrayList<String> filterData = filterData(allRecord, month, year);
        ArrayList<Double> eachOveralRating = calAllOveralRating(filterData);
        for (int i = 0; i < eachOveralRating.size(); i++) {
            overalTotal += eachOveralRating.get(i);
        }
        overalTotal /= eachOveralRating.size();

        return Double.toString(overalTotal);
    }

    @Override
    public ArrayList<String> filterData(ArrayList<String> allRecord, int month, int year) {
        ArrayList<String> newData = new ArrayList<>();
        for (int i = 1; i < allRecord.size(); i++) {

            String dateRent = allRecord.get(i).split(":")[2];
            int yearData = Integer.parseInt(dateRent.split("-")[0]);
            int monthData = Integer.parseInt(dateRent.split("-")[1]);

            if (yearData == year && monthData == month) {
                newData.add(allRecord.get(i));
            } else if (month == -1 && year == -1) {
                newData.add(allRecord.get(i));
            }
        }

        return newData;
    }

    public ArrayList<Double> calAllOveralRating(ArrayList<String> filterData) {
        double oneLine = 0;
        ArrayList<Double> eachOveralRating = new ArrayList<>();
        for (int i = 0; i < filterData.size(); i++) {
            oneLine = 0;
            oneLine += Double.parseDouble(filterData.get(i).split(":")[3]);
            oneLine += Double.parseDouble(filterData.get(i).split(":")[4]);
            oneLine += Double.parseDouble(filterData.get(i).split(":")[5]);
            oneLine += Double.parseDouble(filterData.get(i).split(":")[6]);
            oneLine = oneLine / 4;
            eachOveralRating.add(oneLine);
        }
        return eachOveralRating;

    }

    public ArrayList<String> showAllFilterData(int month, int year) {
        //BookingID:CustomerID:Price:CarID:Start Date:End Date:Rent Time:Request Status:Car return Status:Return Time
        ArrayList<String> finalData = new ArrayList<String>();
        ArrayList<String> realfinalData = new ArrayList<String>();
        ArrayList<String> allRecord = super.viewAll("feedback.txt");
        ArrayList<String> filterData = filterData(allRecord, month, year);
        ArrayList<Double> overal = calAllOveralRating(filterData);

        for (int i = 0; i < filterData.size(); i++) {
            String[] splitted = filterData.get(i).split(":");
            for (int j = 0; j < splitted.length; j++) {
                finalData.add(splitted[j]);
            }
            finalData.add(Double.toString(overal.get(i)));
            String data = String.join(":", finalData.subList(8 * i, 8 * (i + 1)));
            realfinalData.add(data);
        }
        return realfinalData;
    }

}
